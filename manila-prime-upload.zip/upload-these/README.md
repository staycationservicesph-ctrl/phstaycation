# Manila Prime Staycation - split into frontend + backend

```
frontend/   the website + host dashboard (static files) + a tiny /api proxy for Netlify and Cloudflare Pages
top level   the API (Node, Postgres): server.js, package.json, api/, lib/, test/, scripts/   (Render root directory = empty)
```

The original code expects the website and the API on the SAME address (`/api/...`, cookie, cross-site check).
So the frontend host forwards `/api/*` to the backend with a small proxy function (already included). The website code was not changed.

## What changed vs the original (nothing else was touched)
- `public/` -> `frontend/` (byte-identical files).
- `lib/core.js` = copy of `frontend/core.js` (the server must calculate prices itself). A test fails if the two ever differ - edit both together.
- `lib/router.js`: new optional env `ALLOWED_ORIGINS` (website host(s) allowed to call the API) and `PROXY_SECRET` (lets the API trust the real visitor IP sent by the proxy, so the rate limits stay per visitor, not one shared bucket). With neither set, behaviour is exactly as before.
- `server.js`: local dev serves `../frontend`. `vercel.json`: no static output folder.
- New: `frontend/_headers`, `netlify.toml`, `netlify/functions/api.mjs`, `functions/api/[[path]].js`, `test/split.test.js`.

## Added after reviewing airbnb.com (frontend only, nothing removed)
Manila Prime already had Airbnb-style date/guest search, total price for the stay on each card, sort/tower filters and a live calendar. Added:
- **Shareable search links**: `https://YOUR-SITE/?checkin=2026-12-20&checkout=2026-12-23&guests=2` opens with those dates and guests filled in (use it in Facebook posts, ads, WhatsApp replies). The address updates as a guest changes the search. Invalid or past dates are ignored.
- **Save (heart) on unit cards** + "Saved only" filter. Kept only in the guest's own browser (nothing sent to the server); still works if browser storage is blocked.
- Tests: `test/e2e-features.py` (15 checks).

## Deploy order
1. **Backend first** (Vercel, same steps as the old README: GitHub repo with the `backend` folder as root, Neon/Supabase `DATABASE_URL`, `SESSION_SECRET`, `ADMIN_PASSWORD`/`_HASH`, email settings). Add two more env vars:
   - `ALLOWED_ORIGINS` = your website host(s), comma separated, e.g. `manila-prime.netlify.app,manila-prime.pages.dev,www.yourdomain.com`
   - `PROXY_SECRET` = long random text (24+ chars): `node -e "console.log(require('crypto').randomBytes(24).toString('hex'))"`
   Note the backend URL, e.g. `https://manila-prime-api.vercel.app`.
2. **Netlify** - New site from Git (repo folder `frontend` as base directory), no build command, publish directory `.`
   Site settings > Environment variables: `BACKEND_URL` = backend URL, `PROXY_SECRET` = same secret.
   (or CLI: `cd frontend && npx netlify deploy --prod --dir=.`)
3. **Cloudflare Pages** - Workers & Pages > Create > Pages > connect Git (root directory `frontend`), no build command, output directory `/` 
   Settings > Variables and Secrets: `BACKEND_URL`, `PROXY_SECRET` (as secret).
   (or CLI: `cd frontend && npx wrangler pages deploy . --project-name manila-prime`)
4. Add each website host to `ALLOWED_ORIGINS` on the backend, redeploy the backend, then check `https://SITE/api/health`, `/api/units`, `/admin`.

Use ONE of Netlify/Cloudflare as your live address; the other works as a backup/preview.

## Verified here / NOT VERIFIED
- VERIFIED: backend tests 24/24; browser end-to-end 38/39 (the 1 failure, no horizontal scroll at 360px phone width, also fails on your original zip); both proxies tested locally against the running backend (login + cookie, wrong-origin refused, per-visitor rate limit, booking POST).
- NOT VERIFIED: actual deployment to Netlify, Cloudflare or Vercel (no account access from here); real Postgres; email delivery; Cloudflare/Netlify header and function behaviour on the real platforms; that the platform passes the real visitor IP as expected (check: after deploying, 9 wrong admin logins from your phone must not lock out a different device).
