/* One serverless function handles every /api/* route (see lib/router.js). */
const { handle } = require('../lib/app');
module.exports = (req, res) => handle(req, res);
